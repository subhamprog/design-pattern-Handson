package com.design.handson;

public class Test {
	public static void main(String a[]) {
	DBConn one = DBConn.getInstance();
	DBConn two = DBConn.getInstance();
	System.out.println(one.hashCode() == two.hashCode());
	}
}
