package com.design.Facade;

public class Square implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("draw square");
	}

}
