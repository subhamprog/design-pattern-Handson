package com.design.Facade;

public interface Shape {

	public void draw();
}
