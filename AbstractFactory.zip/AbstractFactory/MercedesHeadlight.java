package com.design.AbstractFactory;

public class MercedesHeadlight extends Headlight{
	
	public MercedesHeadlight() {
		System.out.println("Mercedes Headlight added");
	}
}
