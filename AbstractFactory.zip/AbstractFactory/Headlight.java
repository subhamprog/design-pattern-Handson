package com.design.AbstractFactory;

public abstract class Headlight {

}
