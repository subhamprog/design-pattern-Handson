package com.design.AbstractFactory;

public abstract class Tire {

}
