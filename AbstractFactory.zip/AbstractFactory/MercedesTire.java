package com.design.AbstractFactory;

public class MercedesTire extends Tire{
	
	public MercedesTire() {
		System.out.println("Mercedes Tire Added");
	}
}
