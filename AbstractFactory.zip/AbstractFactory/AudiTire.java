package com.design.AbstractFactory;

public class AudiTire extends Tire{
	
	public AudiTire() {
		System.out.println("Audi Tire Added");
	}
}
