package com.design.AbstractFactory;

public class CarFactory {

	public static Factory getFactory(String type)
	{
		if(type.equals("mercedes"))
		{
			return new MercedesFactory();
		}
		else
		{
			return new AudiFactory();
		}
	}
}