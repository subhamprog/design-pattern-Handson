package com.design.AbstractFactory;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Factory f1=CarFactory.getFactory("mercedes");
		f1.makeHeadlight();
		f1.makeTire();

		Factory f2=CarFactory.getFactory("audi");
		f2.makeHeadlight();
		f2.makeTire();
	}

}
