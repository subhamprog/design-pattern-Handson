package com.design.AbstractFactory;

public abstract class Factory {
	
	public abstract Headlight makeHeadlight();
	public abstract Tire makeTire();
	
}
