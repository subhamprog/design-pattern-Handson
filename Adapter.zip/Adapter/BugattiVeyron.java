package com.design.Adapter;

public class BugattiVeyron implements Movable{

	@Override
	public double getSpeed() {

		// This method returns speed in MPH
		return 268;
	}
}
