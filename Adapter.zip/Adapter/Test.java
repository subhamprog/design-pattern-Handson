package com.design.Adapter;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Movable bugattiVeyron = new BugattiVeyron();
    	MovableAdapter bugattiVeyronAdapter = new MovableAdapterImpl(bugattiVeyron);

    	System.out.println(bugattiVeyronAdapter.getSpeed());
	}

}
