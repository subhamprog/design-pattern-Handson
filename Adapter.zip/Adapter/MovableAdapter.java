package com.design.Adapter;

public interface MovableAdapter {
	// this method returns speed in KM/H 
		double getSpeed();
}
