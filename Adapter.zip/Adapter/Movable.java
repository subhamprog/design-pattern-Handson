package com.design.Adapter;

public interface Movable {

	double getSpeed();
}
