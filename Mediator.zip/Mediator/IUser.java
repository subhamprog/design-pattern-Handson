package com.design.Mediator;

public interface IUser {
	
	public void receiveMessage();
	public void sendMessage();
	
}
