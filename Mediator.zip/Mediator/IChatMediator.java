package com.design.Mediator;

public interface IChatMediator {

	public void addUser(IUser user);
	public void sendMessage();
}
