package com.design.Mediator;

public class TestClass {

public static void main(String[] args) {

		ChatMediator chatmediator = new ChatMediator();
		IUser b_user = new BasicUser(chatmediator,"Subham basic");
		IUser p_user = new PlatinumUser(chatmediator,"Sukanta platinum");
		
		chatmediator.addUser(p_user);
		chatmediator.addUser(b_user);

		b_user.sendMessage();
		p_user.sendMessage();
	}
}
