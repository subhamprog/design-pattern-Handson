package com.design.Builder;

public class Coke extends ColdDrinks {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "coke";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 35.0f;
	}
}
