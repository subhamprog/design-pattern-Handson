package com.design.Builder;

public interface Packing {
	
	public String pack();
}
