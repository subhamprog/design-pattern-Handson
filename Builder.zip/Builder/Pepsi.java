package com.design.Builder;

public class Pepsi extends ColdDrinks{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "pepsi";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 30.0f;
	}

}
